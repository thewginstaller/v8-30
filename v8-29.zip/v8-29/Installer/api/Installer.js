const Bash = require( "./Bash.js" );

console.log( Bash.Run( "echo hello" ) );
