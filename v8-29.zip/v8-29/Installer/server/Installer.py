import Bash

print( "Hello" )
Bash.ErrorMsg( "NO!" )
